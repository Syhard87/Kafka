# Kit TP Kafka & Flink (3iL, 2026-2027)

Installation : suivez le Guide d'installation (Word) fourni avec ce kit.

## Contenu
| Fichier | Rôle |
|---|---|
| docker-compose.yml | Kafka 3 brokers (KRaft) + Kafka UI ; profils `flink` et `monitoring` |
| Dockerfile.flink | Image Flink 1.20 + connecteur Kafka SQL |
| generator.py | Générateur de commandes (`python generator.py --help`) |
| requirements.txt | Bibliothèque Python à installer |
| sql/init.sql | Réglages + table `commandes`, chargés au démarrage du client SQL |
| sql/00_init.sql, sql/01_tables.sql | Les deux parties de init.sql, pour lecture |
| sql/02_ca_minute.sql ... 06_skew_minibatch.sql | Requêtes des TP3 à TP6 |
| monitoring/prometheus.yml | Configuration de Prometheus (TP5) |

## Commandes utiles
```
docker compose up -d kafka1 kafka2 kafka3 kafka-ui     # Kafka (tous les TP)
docker compose --profile flink up -d --build           # + Flink (TP3 à TP6)
docker compose --profile monitoring up -d              # + supervision (TP5)
docker exec -it kafka1 bash                            # shell d'un broker, puis : cd /opt/kafka/bin
docker compose exec jobmanager ./bin/sql-client.sh -i /opt/sql/init.sql        # client SQL Flink
docker compose exec jobmanager ./bin/sql-client.sh -i /opt/sql/init.sql -f /opt/sql/02_ca_minute.sql   # lancer un fichier
docker compose --profile flink --profile monitoring stop   # tout arrêter (données conservées)
```

Le client SQL de Flink n'a pas de commande SOURCE : les tables sont chargées au démarrage
avec `-i`, et un fichier d'INSERT se lance avec `-f` (ou en copiant-collant son contenu).

## Topics à créer (la création automatique est désactivée)
| TP | Topics |
|---|---|
| TP0 | commandes (6 partitions) |
| TP1 | tp1-demo |
| TP2 | critique, tolerant, ephemere, profils |
| TP3 | commandes_enrichies, ca_minute |
| TP5 | perf |
| TP6 | ca_pays_minute, alertes |

## Adresses
| Service | Adresse |
|---|---|
| Kafka UI | http://localhost:8080 |
| Flink | http://localhost:8081 |
| Prometheus | http://localhost:9090 |
| Grafana | http://localhost:3000 (admin / admin) |
| Kafka depuis votre machine | localhost:19092, localhost:29092, localhost:39092 |
| Kafka depuis un conteneur | kafka1:9092, kafka2:9092, kafka3:9092 |
| Savepoints | /flink-data/savepoints (volume partagé JobManager / TaskManager) |
