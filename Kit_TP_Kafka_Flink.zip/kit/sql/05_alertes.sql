-- 05_alertes.sql : point de départ des alertes (TP6)
-- Prérequis : topic alertes créé avec kafka-topics.sh.
-- Règle de départ : plus de 3 commandes, ou plus de 1 000 euros, pour un même client en une minute.
-- À vous de l'améliorer (fenêtre glissante, seuils, motif plus précis...).

CREATE TABLE IF NOT EXISTS alertes (
  customer_id STRING,
  w_start     TIMESTAMP(3),
  w_end       TIMESTAMP(3),
  nb          BIGINT,
  total       DOUBLE,
  motif       STRING
) WITH (
  'connector' = 'kafka',
  'topic' = 'alertes',
  'properties.bootstrap.servers' = 'kafka1:9092,kafka2:9092,kafka3:9092',
  'format' = 'json'
);

INSERT INTO alertes
SELECT customer_id, window_start, window_end, COUNT(*) AS nb, SUM(amount) AS total,
       CASE WHEN COUNT(*) > 3 THEN 'plus de 3 commandes en 1 minute'
            ELSE 'plus de 1000 euros en 1 minute' END AS motif
FROM TABLE(
  TUMBLE(TABLE commandes, DESCRIPTOR(ts), INTERVAL '1' MINUTE))
WHERE amount > 0
GROUP BY customer_id, window_start, window_end
HAVING COUNT(*) > 3 OR SUM(amount) > 1000;
