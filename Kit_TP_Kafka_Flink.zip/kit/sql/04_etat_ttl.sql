-- 04_etat_ttl.sql : croissance de l'état et TTL (TP4 partie C)
-- Les résultats partent dans un puits "blackhole" (ils ne sont pas affichés) :
-- on observe le job dans l'interface Flink (http://localhost:8081), onglet Checkpoints, colonne State Size.

CREATE TABLE IF NOT EXISTS etat_sink (
  customer_id STRING,
  nb          BIGINT,
  total       DOUBLE
) WITH ('connector' = 'blackhole');

-- 1) Agrégation SANS fenêtre : un état par client, qui ne disparaît jamais
INSERT INTO etat_sink
SELECT customer_id, COUNT(*), SUM(amount)
FROM commandes
GROUP BY customer_id;

-- 2) Arrêtez le job précédent (interface Flink, bouton Cancel Job), activez le TTL, puis relancez l'INSERT :
-- SET 'table.exec.state.ttl' = '10 min';
