-- 01_tables.sql : table source "commandes" (topic Kafka commandes)
-- ts = event time ; watermark avec 5 secondes de tolérance au retard.
--
-- scan.startup.mode = 'latest-offset' : on lit les messages produits à partir du lancement
-- de la requête. Le topic contient aussi les messages du TP1 (producer.py), qui n'ont pas
-- de champ ts : les relire depuis le début ferait échouer les requêtes avec fenêtre.
CREATE TABLE IF NOT EXISTS commandes (
  order_id    BIGINT,
  customer_id STRING,
  product     STRING,
  amount      DOUBLE,
  country     STRING,
  ts          TIMESTAMP(3),
  WATERMARK FOR ts AS ts - INTERVAL '5' SECOND
) WITH (
  'connector' = 'kafka',
  'topic' = 'commandes',
  'properties.bootstrap.servers' = 'kafka1:9092,kafka2:9092,kafka3:9092',
  'properties.group.id' = 'flink',
  'scan.startup.mode' = 'latest-offset',
  'format' = 'json',
  'json.ignore-parse-errors' = 'true'
);
