-- 02_ca_minute.sql : chiffre d'affaires par minute (TP3 partie D, TP4 parties D et E)
-- Prérequis : topic ca_minute créé (TP3 partie A).
-- La table n'est créée que si elle n'existe pas : au TP4 partie E, la version exactly-once
-- que vous avez créée est conservée.
CREATE TABLE IF NOT EXISTS ca_minute (
  w_start TIMESTAMP(3),
  w_end   TIMESTAMP(3),
  nb      BIGINT,
  total   DOUBLE
) WITH (
  'connector' = 'kafka',
  'topic' = 'ca_minute',
  'properties.bootstrap.servers' = 'kafka1:9092,kafka2:9092,kafka3:9092',
  'format' = 'json'
);

INSERT INTO ca_minute
SELECT window_start, window_end, COUNT(*) AS nb, SUM(amount) AS total
FROM TABLE(
  TUMBLE(TABLE commandes, DESCRIPTOR(ts), INTERVAL '1' MINUTE))
WHERE amount > 0
GROUP BY window_start, window_end;
