-- 03_fenetres.sql : les trois types de fenêtres (TP4 partie A)
-- Copiez-collez les requêtes UNE PAR UNE dans le client SQL. Ctrl+C pour arrêter une requête.

-- 1) Tumbling : nombre de commandes et chiffre d'affaires par minute
SELECT window_start, window_end, COUNT(*) AS nb, ROUND(SUM(amount), 2) AS total
FROM TABLE(
  TUMBLE(TABLE commandes, DESCRIPTOR(ts), INTERVAL '1' MINUTE))
GROUP BY window_start, window_end;

-- 2) Glissante (HOP) : taille 5 minutes, pas 1 minute
--    Attention à l'ordre des paramètres : d'abord le PAS, puis la TAILLE.
SELECT window_start, window_end, COUNT(*) AS nb, ROUND(AVG(amount), 2) AS panier_moyen
FROM TABLE(
  HOP(TABLE commandes, DESCRIPTOR(ts), INTERVAL '1' MINUTE, INTERVAL '5' MINUTE))
GROUP BY window_start, window_end;

-- 3) Session par client : la session se ferme après 30 secondes sans commande de ce client
--    Conseil : lancez le générateur avec --customers 50 pour voir des sessions de plusieurs commandes.
SELECT customer_id,
       SESSION_START(ts, INTERVAL '30' SECOND) AS debut_session,
       SESSION_END(ts, INTERVAL '30' SECOND)   AS fin_session,
       COUNT(*) AS nb
FROM commandes
GROUP BY customer_id, SESSION(ts, INTERVAL '30' SECOND);
