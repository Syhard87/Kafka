-- 06_skew_minibatch.sql : déséquilibre de clés et optimisations (TP5 partie C)
-- Générateur : python generator.py --rate 3000 --duration 0 --skew 0.8
-- Les résultats partent dans un puits "blackhole" : on observe les sous-tâches dans l'interface Flink.

SET 'parallelism.default' = '4';

CREATE TABLE IF NOT EXISTS skew_sink (
  customer_id STRING,
  nb          BIGINT
) WITH ('connector' = 'blackhole');

-- 1) AVANT : agrégation simple. Ouvrez l'opérateur d'agrégation et comparez les sous-tâches.
INSERT INTO skew_sink
SELECT customer_id, COUNT(*) FROM commandes GROUP BY customer_id;

-- 2) APRÈS : arrêtez le job précédent (Cancel Job), exécutez les 4 SET ci-dessous, puis relancez l'INSERT.
SET 'table.exec.mini-batch.enabled' = 'true';
SET 'table.exec.mini-batch.allow-latency' = '2 s';
SET 'table.exec.mini-batch.size' = '5000';
SET 'table.optimizer.agg-phase-strategy' = 'TWO_PHASE';
