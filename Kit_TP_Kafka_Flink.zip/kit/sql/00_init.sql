-- 00_init.sql : réglages de la session SQL
-- Affichage des résultats directement dans le terminal
SET 'sql-client.execution.result-mode' = 'tableau';
-- Checkpoint toutes les 10 secondes pour les jobs lancés depuis cette session
SET 'execution.checkpointing.interval' = '10s';
