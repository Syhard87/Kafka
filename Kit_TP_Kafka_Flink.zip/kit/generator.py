#!/usr/bin/env python3
"""Générateur de commandes pour les TP Kafka & Flink (3iL).

Exemples :
  python generator.py --rate 10 --duration 20
  python generator.py --rate 50 --duration 0                       # sans fin (Ctrl+C pour arrêter)
  python generator.py --rate 50 --duration 300 --late-prob 0.1 --max-delay 40
  python generator.py --rate 500 --duration 0 --customers 200000
  python generator.py --rate 3000 --duration 0 --skew 0.8
  python generator.py --dry-run                                    # affiche 5 messages, sans Kafka

Chaque message (clé = customer_id) :
  {"order_id": 1732266000000, "customer_id": "C000042", "product": "clavier",
   "amount": 42.5, "country": "fr", "ts": "2026-11-22 10:15:03.123"}
"""
import argparse
import json
import random
import sys
import time
from datetime import datetime, timedelta

PRODUCTS = ["clavier", "souris", "ecran", "casque", "webcam", "disque", "cable", "chargeur"]
COUNTRIES = ["fr", "be", "ch", "de", "es", "it", "tn", "ma"]
HOT_CUSTOMER = "C000001"


def parse_args():
    p = argparse.ArgumentParser(description="Générateur de commandes pour les TP Kafka & Flink")
    p.add_argument("--bootstrap", default="localhost:19092,localhost:29092,localhost:39092",
                   help="adresses des brokers vues depuis votre machine")
    p.add_argument("--topic", default="commandes", help="topic de destination (défaut : commandes)")
    p.add_argument("--rate", type=float, default=10, help="messages par seconde (défaut : 10)")
    p.add_argument("--duration", type=float, default=60,
                   help="durée en secondes, 0 = sans fin (défaut : 60)")
    p.add_argument("--customers", type=int, default=1000, help="nombre de clients différents (défaut : 1000)")
    p.add_argument("--skew", type=float, default=0.0,
                   help="part des messages envoyés par un seul client, entre 0 et 1 (défaut : 0)")
    p.add_argument("--late-prob", type=float, default=0.0,
                   help="probabilité qu'un événement soit en retard, entre 0 et 1 (défaut : 0)")
    p.add_argument("--max-delay", type=float, default=30,
                   help="retard maximal en secondes d'un événement tardif (défaut : 30)")
    p.add_argument("--invalid-prob", type=float, default=0.03,
                   help="probabilité d'un montant invalide (<= 0) (défaut : 0.03)")
    p.add_argument("--seed", type=int, default=None, help="graine aléatoire, pour rejouer la même suite")
    p.add_argument("--dry-run", action="store_true", help="affiche 5 messages sans se connecter à Kafka")
    a = p.parse_args()
    if a.rate <= 0:
        p.error("--rate doit être supérieur à 0")
    for name in ("skew", "late_prob", "invalid_prob"):
        if not 0 <= getattr(a, name) <= 1:
            p.error(f"--{name.replace('_', '-')} doit être compris entre 0 et 1")
    if a.customers < 1:
        p.error("--customers doit être au moins 1")
    return a


def fmt_ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S.") + f"{dt.microsecond // 1000:03d}"


def make_event(order_id, args, rng):
    if args.skew > 0 and rng.random() < args.skew:
        customer = HOT_CUSTOMER
    else:
        customer = f"C{rng.randint(1, args.customers):06d}"
    event_time = datetime.now()
    late = args.late_prob > 0 and rng.random() < args.late_prob
    if late:
        event_time -= timedelta(seconds=rng.uniform(1, args.max_delay))
    amount = round(rng.uniform(5, 500), 2)
    if rng.random() < args.invalid_prob:
        amount = rng.choice([0.0, -amount])
    evt = {
        "order_id": order_id,
        "customer_id": customer,
        "product": rng.choice(PRODUCTS),
        "amount": amount,
        "country": rng.choice(COUNTRIES),
        "ts": fmt_ts(event_time),
    }
    return customer, evt, late


def main():
    args = parse_args()
    rng = random.Random(args.seed)
    base_id = int(time.time()) * 1000

    if args.dry_run:
        for i in range(5):
            key, evt, late = make_event(base_id + i, args, rng)
            print(f"clé={key}  {json.dumps(evt, ensure_ascii=False)}" + ("   (en retard)" if late else ""))
        return 0

    try:
        from confluent_kafka import Producer, KafkaException
    except ImportError:
        print("ERREUR : la bibliothèque confluent-kafka n'est pas installée.\n"
              "        Activez votre environnement virtuel puis : pip install confluent-kafka")
        return 1

    stats = {"ok": 0, "err": 0, "last_err": None}

    def on_delivery(err, msg):
        if err:
            stats["err"] += 1
            stats["last_err"] = str(err)
        else:
            stats["ok"] += 1

    producer = Producer({
        "bootstrap.servers": args.bootstrap,
        "client.id": "tp3il-generator",
        "acks": "all",
        "enable.idempotence": True,
        "linger.ms": 5,
    })

    # Vérification de la connexion et de l'existence du topic
    try:
        meta = producer.list_topics(timeout=10)
    except KafkaException as e:
        print(f"ERREUR : impossible de joindre Kafka sur {args.bootstrap}\n"
              f"        Le cluster est-il démarré ? (docker compose ps)\n        Détail : {e}")
        return 1
    if args.topic not in meta.topics:
        print(f"ERREUR : le topic '{args.topic}' n'existe pas (la création automatique est désactivée).\n"
              f"        Créez-le d'abord avec kafka-topics.sh --create --topic {args.topic} ...")
        return 1

    duration_txt = "sans fin (Ctrl+C pour arrêter)" if args.duration == 0 else f"{args.duration:g} s"
    print(f"Envoi vers '{args.topic}' : {args.rate:g} msg/s, {duration_txt}, "
          f"{args.customers} clients, skew={args.skew:g}, retard={args.late_prob:g} (max {args.max_delay:g} s)")

    interval = 1.0 / args.rate
    start = time.monotonic()
    next_report = start + 5
    sent = late_count = 0
    try:
        while True:
            now = time.monotonic()
            if args.duration > 0 and now - start >= args.duration:
                break
            target = start + sent * interval
            if target > now:
                time.sleep(min(target - now, 0.5))
                continue
            key, evt, late = make_event(base_id + sent, args, rng)
            payload = json.dumps(evt, ensure_ascii=False)
            while True:
                try:
                    producer.produce(args.topic, key=key, value=payload, callback=on_delivery)
                    break
                except BufferError:
                    producer.poll(0.1)
            producer.poll(0)
            sent += 1
            late_count += late
            if now >= next_report:
                elapsed = now - start
                print(f"[{elapsed:6.0f} s] envoyés={sent}  confirmés={stats['ok']}  erreurs={stats['err']}  "
                      f"débit≈{sent / elapsed:.0f} msg/s  en retard={late_count}")
                if stats["last_err"]:
                    print(f"         dernière erreur : {stats['last_err']}")
                next_report = now + 5
    except KeyboardInterrupt:
        print("\nArrêt demandé...")
    finally:
        remaining = producer.flush(15)
    print(f"Terminé : {sent} messages envoyés, {stats['ok']} confirmés, {stats['err']} erreurs"
          + (f", {remaining} non confirmés" if remaining else "") + ".")
    return 0 if stats["err"] == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
